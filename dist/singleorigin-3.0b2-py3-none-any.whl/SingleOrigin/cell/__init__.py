"""Module for reading .cif files and manipulating crystal structures."""
